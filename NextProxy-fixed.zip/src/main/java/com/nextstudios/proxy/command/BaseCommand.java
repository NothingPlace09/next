package com.nextstudios.proxy.command;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.Messages;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.user.UserManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public abstract class BaseCommand
implements SimpleCommand {
    protected final NextProxy plugin;
    protected final CommandSpec spec;
    private final Messages messages;

    protected BaseCommand(NextProxy plugin, CommandSpec spec, Messages messages) {
        this.plugin = plugin;
        this.spec = spec;
        this.messages = messages;
    }

    protected BaseCommand(Module owner, CommandSpec spec) {
        this(owner.plugin(), spec, owner.messages());
    }

    public final boolean hasPermission(SimpleCommand.Invocation invocation) {
        return this.spec.allows(invocation.source());
    }

    public final void execute(SimpleCommand.Invocation invocation) {
        try {
            this.execute(invocation.source(), invocation.arguments());
        }
        catch (RuntimeException e) {
            this.fail(invocation.source(), e);
        }
    }

    public final List<String> suggest(SimpleCommand.Invocation invocation) {
        try {
            return this.suggest(invocation.source(), invocation.arguments());
        }
        catch (RuntimeException e) {
            return List.of();
        }
    }

    protected abstract void execute(CommandSource var1, String[] var2);

    protected List<String> suggest(CommandSource source, String[] args) {
        return List.of();
    }

    protected Messages messages() {
        return this.messages;
    }

    protected UserManager users() {
        return this.plugin.users();
    }

    protected Player requirePlayer(CommandSource source) {
        if (source instanceof Player) {
            return (Player)source;
        }
        this.messages().send(source, "general.players-only", new TagResolver[0]);
        return null;
    }

    protected Void fail(CommandSource source, Throwable error) {
        this.plugin.logger().error("Errore durante /{}", this.spec.name(), error);
        this.messages().send(source, "general.error", new TagResolver[0]);
        return null;
    }

    protected static String join(String[] args, int from) {
        return from >= args.length ? "" : String.join(" ", Arrays.copyOfRange(args, from, args.length)).trim();
    }

    protected static List<String> filter(Collection<String> options, String input) {
        String lower = input.toLowerCase(Locale.ROOT);
        ArrayList<String> result = new ArrayList<String>();
        for (String option : options) {
            if (!option.toLowerCase(Locale.ROOT).startsWith(lower)) continue;
            result.add(option);
        }
        return result;
    }

    protected static int parsePositive(String input, int fallback) {
        try {
            int value = Integer.parseInt(input);
            return value > 0 ? value : fallback;
        }
        catch (NumberFormatException e) {
            return fallback;
        }
    }
}
