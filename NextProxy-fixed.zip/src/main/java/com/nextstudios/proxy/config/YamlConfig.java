package com.nextstudios.proxy.config;

import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import org.yaml.snakeyaml.error.YAMLException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class YamlConfig {
    private final Map<String, Object> values;
    private final Map<String, Object> defaults;

    private YamlConfig(Map<String, Object> values, Map<String, Object> defaults) {
        this.values = values;
        this.defaults = defaults;
    }

    public static YamlConfig of(Map<String, Object> values) {
        return new YamlConfig(new LinkedHashMap<String, Object>(values), Collections.emptyMap());
    }

    public static YamlConfig empty() {
        return new YamlConfig(Collections.emptyMap(), Collections.emptyMap());
    }

    public static YamlConfig load(Path file, String resource) throws IOException {
        byte[] bundled;
        try (InputStream in = YamlConfig.class.getClassLoader().getResourceAsStream(resource);){
            if (in == null) {
                throw new IOException("Risorsa mancante nel jar: " + resource);
            }
            bundled = in.readAllBytes();
        }
        if (Files.notExists(file, new LinkOption[0])) {
            Files.createDirectories(file.getParent(), new FileAttribute[0]);
            Files.write(file, bundled, new OpenOption[0]);
        }
        Map<String, Object> defaults = YamlConfig.parse(new String(bundled, StandardCharsets.UTF_8), resource);
        Map<String, Object> values = YamlConfig.parse(Files.readString(file, StandardCharsets.UTF_8), file.getFileName().toString());
        return new YamlConfig(values, defaults);
    }

    public static YamlConfig loadOptional(Path file, String resource) throws IOException {
        try (InputStream in = YamlConfig.class.getClassLoader().getResourceAsStream(resource);) {
            if (in == null) {
                return YamlConfig.empty();
            }
        }
        return YamlConfig.load(file, resource);
    }

    private static Map<String, Object> parse(String content, String source) throws IOException {
        Object loaded;
        LoaderOptions options = new LoaderOptions();
        options.setAllowDuplicateKeys(false);
        options.setMaxAliasesForCollections(50);
        Yaml yaml = new Yaml(new SafeConstructor(options));
        try {
            loaded = yaml.load(content);
        }
        catch (YAMLException e) {
            throw new IOException("Errore di sintassi in " + source + ": " + e.getMessage(), e);
        }
        if (loaded == null) {
            return new LinkedHashMap<String, Object>();
        }
        if (!(loaded instanceof Map)) {
            throw new IOException(source + ": la radice del file deve essere una sezione");
        }
        Map map = (Map)loaded;
        return YamlConfig.normalize(map);
    }

    private static Map<String, Object> normalize(Map<?, ?> map) {
        LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            result.put(String.valueOf(entry.getKey()), YamlConfig.normalizeValue(entry.getValue()));
        }
        return result;
    }

    private static Object normalizeValue(Object value) {
        if (value instanceof Map) {
            Map map = (Map)value;
            return YamlConfig.normalize(map);
        }
        if (value instanceof List) {
            List list = (List)value;
            ArrayList<Object> result = new ArrayList<Object>(list.size());
            for (Object element : list) {
                result.add(YamlConfig.normalizeValue(element));
            }
            return result;
        }
        return value;
    }

    public YamlConfig section(String path) {
        return new YamlConfig(YamlConfig.asMap(YamlConfig.find(this.values, path)), YamlConfig.asMap(YamlConfig.find(this.defaults, path)));
    }

    public Object get(String path) {
        Object value = YamlConfig.find(this.values, path);
        return value != null ? value : YamlConfig.find(this.defaults, path);
    }

    public boolean contains(String path) {
        return this.get(path) != null;
    }

    public String getString(String path, String def) {
        Object value = this.get(path);
        return value == null || value instanceof Map || value instanceof List ? def : String.valueOf(value);
    }

    public int getInt(String path, int def) {
        return (int)this.getLong(path, def);
    }

    public long getLong(String path, long def) {
        Object value = this.get(path);
        if (value instanceof Number) {
            Number number = (Number)value;
            return number.longValue();
        }
        if (value instanceof String) {
            String text = (String)value;
            try {
                return Long.parseLong(text.trim());
            }
            catch (NumberFormatException ignored) {
                return def;
            }
        }
        return def;
    }

    public boolean getBoolean(String path, boolean def) {
        Object value = this.get(path);
        if (value instanceof Boolean) {
            Boolean bool = (Boolean)value;
            return bool;
        }
        if (value instanceof String) {
            String text = (String)value;
            return Boolean.parseBoolean(text.trim());
        }
        return def;
    }

    public List<String> getStringList(String path) {
        Object value = this.get(path);
        if (value instanceof List) {
            List list = (List)value;
            ArrayList<String> result = new ArrayList<String>(list.size());
            for (Object element : list) {
                if (element == null) continue;
                result.add(String.valueOf(element));
            }
            return result;
        }
        if (value instanceof String) {
            String text = (String)value;
            return List.of(text);
        }
        return List.of();
    }

    public List<Object> getList(String path) {
        Object value = this.get(path);
        if (value instanceof List) {
            List list = (List)value;
            return Collections.unmodifiableList(new ArrayList(list));
        }
        return List.of();
    }

    public Set<String> getKeys(String path) {
        Object user = YamlConfig.find(this.values, path);
        if (user instanceof Map) {
            Map map = (Map)user;
            return YamlConfig.keysOf(map);
        }
        return YamlConfig.keysOf(YamlConfig.asMap(YamlConfig.find(this.defaults, path)));
    }

    private static Set<String> keysOf(Map<?, ?> map) {
        LinkedHashSet<String> keys = new LinkedHashSet<String>();
        for (Object key : map.keySet()) {
            keys.add(String.valueOf(key));
        }
        return keys;
    }

    private static Object find(Map<String, Object> root, String path) {
        if (path.isEmpty()) {
            return root;
        }
        Object current = root;
        for (String part : path.split("\\.")) {
            if (!(current instanceof Map)) {
                return null;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) current;
            current = map.get(part);
            if (current != null) continue;
            return null;
        }
        return current;
    }

    private static Map<String, Object> asMap(Object value) {
        return value instanceof Map ? (Map)value : Map.of();
    }
}
