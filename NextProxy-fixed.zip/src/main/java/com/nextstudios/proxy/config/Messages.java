package com.nextstudios.proxy.config;

import com.nextstudios.proxy.util.Text;
import com.nextstudios.proxy.util.TimeFormat;
import java.util.Arrays;
import java.util.List;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class Messages {
    private final YamlConfig yaml;
    private final Messages fallback;
    private final String prefixText;
    private final TagResolver prefix;
    private final TimeFormat time;

    public Messages(YamlConfig yaml, YamlConfig config) {
        this(yaml, null, yaml.getString("prefix", ""), new TimeFormat(yaml, config));
    }

    private Messages(YamlConfig yaml, Messages fallback, String prefixText, TimeFormat time) {
        this.yaml = yaml;
        this.fallback = fallback;
        this.prefixText = prefixText;
        this.prefix = Placeholder.parsed("prefix", Text.legacyToMini(prefixText));
        this.time = time;
    }

    public static Messages module(YamlConfig file, YamlConfig config, Messages global) {
        String prefix = file.getString("prefix", "");
        if (prefix.isEmpty()) {
            prefix = global.prefixText();
        }
        YamlConfig section = file.section("messages");
        TimeFormat time = section.contains("time") ? new TimeFormat(section, config) : global.time();
        return new Messages(section, global, prefix, time);
    }

    public String prefixText() {
        return this.prefixText;
    }

    public TimeFormat time() {
        return this.time;
    }

    private Object lookup(String key) {
        Object value = this.yaml.get(key);
        if (value == null && this.fallback != null) {
            return this.fallback.yaml.get(key);
        }
        return value;
    }

    public String raw(String key) {
        Object value = this.lookup(key);
        if (value == null) {
            return key;
        }
        if (value instanceof List) {
            List<?> lines = (List<?>)value;
            StringBuilder out = new StringBuilder();
            for (Object line : lines) {
                if (out.length() > 0) {
                    out.append('\n');
                }
                out.append(line == null ? "" : line);
            }
            return out.toString();
        }
        return String.valueOf(value);
    }

    public Component get(String key, TagResolver... resolvers) {
        return this.parse(this.raw(key), resolvers);
    }

    public Component parse(String template, TagResolver... resolvers) {
        TagResolver[] all = Arrays.copyOf(resolvers, resolvers.length + 1);
        all[resolvers.length] = this.prefix;
        return Text.parse(template, all);
    }

    public void send(Audience audience, String key, TagResolver... resolvers) {
        String raw = this.raw(key);
        if (!raw.isEmpty()) {
            audience.sendMessage(this.parse(raw, resolvers));
        }
    }

    public void usage(Audience audience, String key) {
        if (this.lookup(key) instanceof List) {
            this.send(audience, key, new TagResolver[0]);
            return;
        }
        this.send(audience, "general.usage", Placeholder.parsed("usage", Text.legacyToMini(this.raw(key))));
    }
}
