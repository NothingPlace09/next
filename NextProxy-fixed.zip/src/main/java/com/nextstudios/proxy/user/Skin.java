package com.nextstudios.proxy.user;

public record Skin(String value, String signature) {
}
