package com.nextstudios.proxy.module.staffchat;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.user.User;
import com.nextstudios.proxy.util.Text;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class StaffChatModule
extends Module {
    private static final int MAX_LENGTH = 256;
    private String readPermission;
    private boolean logToConsole;
    private CommandSpec chatSpec;

    public StaffChatModule(NextProxy plugin) {
        super(plugin, "staffchat");
    }

    @Override
    protected void onEnable() {
        this.readPermission = this.config().getString("read-permission", "NextProxy.staffchat");
        this.logToConsole = this.config().getBoolean("log-to-console", true);
        this.chatSpec = this.spec("staffchat");
        this.command("staffchat", spec -> new StaffChatCommand((CommandSpec)spec));
        this.bridgeHandler(65, (player, in) -> {
            String text = in.readUTF();
            if (this.chatSpec.allows((CommandSource)player) && this.users().get(player).staffChat()) {
                this.send((CommandSource)player, text);
            }
        });
    }

    public void send(CommandSource from, String raw) {
        String string;
        String text = raw.strip();
        if (text.isEmpty()) {
            return;
        }
        if (text.length() > 256) {
            text = text.substring(0, 256);
        }
        if (from instanceof Player) {
            Player player = (Player)from;
            string = player.getCurrentServer().map(connection -> connection.getServerInfo().getName()).orElse("-");
        } else {
            string = "proxy";
        }
        String server = string;
        Component message = this.messages().get("format", Text.token("player", this.plugin.nameOf(from)), Text.token("server", server), Text.component("message", Text.userText(text, this.plugin.canUseColors(from))));
        for (Player viewer : this.proxy().getAllPlayers()) {
            if (!this.readPermission.isEmpty() && !viewer.hasPermission(this.readPermission)) continue;
            viewer.sendMessage(message);
        }
        if (this.logToConsole) {
            this.logger().info(Text.plain(message));
        }
    }

    private final class StaffChatCommand
    extends BaseCommand {
        StaffChatCommand(CommandSpec spec) {
            super(StaffChatModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (args.length > 0) {
                StaffChatModule.this.send(source, StaffChatCommand.join(args, 0));
                return;
            }
            Player player = this.requirePlayer(source);
            if (player == null) {
                return;
            }
            User user = this.users().get(player);
            boolean enabled = !user.staffChat();
            user.staffChat(enabled);
            this.users().save(user);
            this.plugin.bridge().push(player);
            this.messages().send((Audience)player, enabled ? "toggle-on" : "toggle-off", new TagResolver[0]);
            if (enabled) {
                this.plugin.bridge().warnIfMissing(player, "no-bridge");
            }
        }
    }
}
