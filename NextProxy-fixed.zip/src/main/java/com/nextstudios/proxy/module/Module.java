package com.nextstudios.proxy.module;

import com.velocitypowered.api.command.Command;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.scheduler.ScheduledTask;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.bridge.BridgeManager;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.Messages;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.user.UserManager;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.slf4j.Logger;

public abstract class Module {
    protected final NextProxy plugin;
    private final String id;
    private final List<Object> listeners = new ArrayList<Object>();
    private final List<ScheduledTask> tasks = new ArrayList<ScheduledTask>();
    private volatile boolean enabled;

    protected Module(NextProxy plugin, String id) {
        this.plugin = plugin;
        this.id = id;
    }

    public final String id() {
        return this.id;
    }

    public final boolean isEnabled() {
        return this.enabled;
    }

    public final boolean isConfiguredEnabled() {
        return this.plugin.moduleConfig(this.id).getBoolean("enabled", true);
    }

    public final NextProxy plugin() {
        return this.plugin;
    }

    public final Messages messages() {
        return this.plugin.moduleMessages(this.id);
    }

    public final synchronized void enable() {
        if (this.enabled) {
            return;
        }
        try {
            this.onEnable();
            this.enabled = true;
        }
        catch (RuntimeException e) {
            this.cleanup();
            throw e;
        }
    }

    public final synchronized void disable() {
        if (!this.enabled) {
            return;
        }
        this.enabled = false;
        try {
            this.onDisable();
        }
        finally {
            this.cleanup();
        }
    }

    private void cleanup() {
        for (Object listener : this.listeners) {
            this.plugin.proxy().getEventManager().unregisterListener((Object)this.plugin, listener);
        }
        this.listeners.clear();
        for (ScheduledTask task : this.tasks) {
            task.cancel();
        }
        this.tasks.clear();
        this.plugin.commands().unregisterAll(this);
        this.plugin.bridge().unregisterHandlers(this);
    }

    protected abstract void onEnable();

    protected void onDisable() {
    }

    protected YamlConfig config() {
        return this.plugin.moduleConfig(this.id);
    }

    protected UserManager users() {

        return this.plugin.users();
    }

    protected ProxyServer proxy() {
        return this.plugin.proxy();
    }

    protected Logger logger() {
        return this.plugin.logger();
    }

    protected void listen(Object listener) {
        this.plugin.proxy().getEventManager().register((Object)this.plugin, listener);
        this.listeners.add(listener);
    }

    protected CommandSpec spec(String key) {
        return CommandSpec.read(this.config().section("commands." + key), key);
    }

    protected void command(String key, Function<CommandSpec, ? extends Command> factory) {
        CommandSpec spec = this.spec(key);
        this.plugin.commands().register(this, spec, factory.apply(spec));
    }

    protected void repeat(long delay, long period, TimeUnit unit, Runnable task) {
        Runnable safe = () -> {
            try {
                task.run();
            }
            catch (RuntimeException e) {
                this.logger().error("Errore in un task del modulo {}", (Object)this.id, (Object)e);
            }
        };
        this.tasks.add(this.plugin.proxy().getScheduler().buildTask((Object)this.plugin, safe).delay(delay, unit).repeat(period, unit).schedule());
    }

    protected void bridgeHandler(int type, BridgeManager.Handler handler) {
        this.plugin.bridge().registerHandler(this, type, handler);
    }
}
