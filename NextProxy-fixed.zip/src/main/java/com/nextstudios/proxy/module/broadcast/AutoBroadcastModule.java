package com.nextstudios.proxy.module.broadcast;

import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.module.Module;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class AutoBroadcastModule
extends Module {
    private final List<String> templates = new ArrayList<String>();
    private final Set<String> excludedServers = new HashSet<String>();
    private boolean random;
    private int minPlayers;
    private int next;

    public AutoBroadcastModule(NextProxy plugin) {
        super(plugin, "autobroadcast");
    }

    @Override
    protected void onEnable() {
        this.templates.clear();
        for (Object entry : this.config().getList("broadcasts")) {

            if (entry instanceof List) {
                List lines = (List)entry;
                ArrayList<String> parts = new ArrayList<String>();
                for (Object line : lines) {
                    parts.add(line == null ? "" : String.valueOf(line));
                }
                this.templates.add(String.join((CharSequence)"\n", parts));
                continue;
            }
            if (entry == null) continue;
            this.templates.add(String.valueOf(entry));
        }
        this.excludedServers.clear();
        for (String server : this.config().getStringList("excluded-servers")) {
            this.excludedServers.add(server.toLowerCase(Locale.ROOT));
        }
        this.random = this.config().getBoolean("random", false);
        this.minPlayers = Math.max(0, this.config().getInt("min-players", 1));
        this.next = this.random ? -1 : 0;
        long interval = Math.max(5L, this.config().getLong("interval-seconds", 300L));
        if (this.templates.isEmpty()) {
            this.logger().warn("AutoBroadcast attivo ma senza broadcast in modules/autobroadcast.yml");

            return;
        }
        this.repeat(interval, interval, TimeUnit.SECONDS, this::broadcastNext);
    }

    private synchronized void broadcastNext() {
        int index;
        if (this.proxy().getPlayerCount() < this.minPlayers || this.templates.isEmpty()) {
            return;
        }
        int size = this.templates.size();
        if (!this.random || size == 1) {
            index = this.next % size;
            this.next = index + 1;
        } else {
            index = ThreadLocalRandom.current().nextInt(this.next >= 0 ? size - 1 : size);
            if (this.next >= 0 && index >= this.next) {
                ++index;
            }
            this.next = index;
        }
        Component message = this.messages().parse(this.templates.get(index), new TagResolver[0]);
        for (Player player : this.proxy().getAllPlayers()) {
            boolean excluded = player.getCurrentServer().map(connection -> this.excludedServers.contains(connection.getServerInfo().getName().toLowerCase(Locale.ROOT))).orElse(false);
            if (excluded) continue;
            player.sendMessage(message);
        }
    }
}
