package com.nextstudios.proxy.module.report;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.util.Names;
import com.nextstudios.proxy.util.Text;

import java.util.List;
import java.util.Optional;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class ReportModule
extends Module {
    private String receivePermission;
    private String bypassCooldownPermission;
    private long cooldownMillis;
    private int minLength;
    private int maxLength;
    private boolean logToConsole;

    public ReportModule(NextProxy plugin) {
        super(plugin, "report");
    }

    @Override
    protected void onEnable() {
        this.receivePermission = this.config().getString("receive-permission", "NextProxy.report.receive");
        this.bypassCooldownPermission = this.config().getString("bypass-cooldown-permission", "NextProxy.report.bypass");
        this.cooldownMillis = Math.max(0L, this.config().getLong("cooldown-seconds", 60L)) * 1000L;
        this.minLength = Math.max(1, this.config().getInt("min-reason-length", 3));
        this.maxLength = Math.max(this.minLength, this.config().getInt("max-reason-length", 100));
        this.logToConsole = this.config().getBoolean("log-to-console", true);
        this.command("report", spec -> new ReportCommand((CommandSpec)spec));
    }

    private final class ReportCommand
    extends BaseCommand {
        ReportCommand(CommandSpec spec) {
            super(ReportModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            long wait;
            Player reporter = this.requirePlayer(source);
            if (reporter == null) {
                return;
            }
            if (args.length < 2) {
                this.messages().usage((Audience)source, "usage");
                return;
            }
            Optional<Player> found = this.users().find((CommandSource)reporter, args[0]);
            if (found.isEmpty()) {
                this.messages().send((Audience)source, "general.player-not-found", Text.token("player", args[0]));
                return;
            }
            Player reported = found.get();
            if (reported.equals((Object)reporter)) {
                this.messages().send((Audience)source, "self", new TagResolver[0]);
                return;
            }
            String reason = ReportCommand.join(args, 1);
            if (reason.length() < ReportModule.this.minLength) {
                this.messages().send((Audience)source, "reason-too-short", new TagResolver[0]);
                return;
            }
            if (reason.length() > ReportModule.this.maxLength) {
                this.messages().send((Audience)source, "reason-too-long", Text.token("max", ReportModule.this.maxLength));
                return;
            }
            if ((ReportModule.this.bypassCooldownPermission.isEmpty() || !reporter.hasPermission(ReportModule.this.bypassCooldownPermission)) && (wait = this.users().get(reporter).tryCooldown("report", ReportModule.this.cooldownMillis)) > 0L) {
                this.messages().send((Audience)source, "general.cooldown", Text.literal("time", this.messages().time().duration(wait)));
                return;
            }
            String server = reported.getCurrentServer().map(connection -> connection.getServerInfo().getName()).orElse("-");
            TextComponent reasonText = Component.text((String)reason);
            int receivers = 0;
            for (Player staff : ReportModule.this.proxy().getAllPlayers()) {
                if (ReportModule.this.receivePermission.isEmpty() || !staff.hasPermission(ReportModule.this.receivePermission)) continue;
                this.messages().send((Audience)staff, "alert", Text.token("reporter", this.users().displayName(reporter, (CommandSource)staff)), Text.token("reported", this.users().displayName(reported, (CommandSource)staff)), Text.component("reason", (Component)reasonText), Text.token("server", server));
                ++receivers;
            }
            this.messages().send((Audience)source, "sent", new TagResolver[0]);
            if (receivers == 0) {
                this.messages().send((Audience)source, "no-staff", new TagResolver[0]);
            }
            WebhookService hooks = this.plugin.webhooks();
            if (hooks != null) {
                hooks.report(reporter.getUsername(), reported.getUsername(), reason, server, Names.ipOf(reporter));
            }
            if (ReportModule.this.logToConsole) {
                ReportModule.this.logger().info("[REPORT] {} ha reportato {} per \"{}\" nel server {}", new Object[]{reporter.getUsername(), reported.getUsername(), reason, server});
            }

        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            return args.length <= 1 ? this.users().suggest(source, args.length == 0 ? "" : args[0]) : List.of();
        }
    }
}
