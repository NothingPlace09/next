package com.nextstudios.proxy.module.custom;

import com.velocitypowered.api.command.CommandSource;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class CustomCommandsModule
extends Module {
    public CustomCommandsModule(NextProxy plugin) {
        super(plugin, "customcommands");
    }

    @Override
    protected void onEnable() {
        for (String key : this.config().getKeys("commands")) {
            String message = String.join((CharSequence)"\n", this.config().getStringList("commands." + key + ".message"));
            try {
                this.command(key, spec -> new InfoCommand((CommandSpec)spec, message));
            }
            catch (IllegalArgumentException e) {
                this.logger().warn("Comando personalizzato '{}' ignorato: {}", (Object)key, (Object)e.getMessage());
            }
        }
    }

    private final class InfoCommand
    extends BaseCommand {
        private final String message;

        InfoCommand(CommandSpec spec, String message) {
            super(CustomCommandsModule.this, spec);
            this.message = message;
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (!this.message.isEmpty()) {
                source.sendMessage(this.messages().parse(this.message, new TagResolver[0]));
            }
        }
    }
}
