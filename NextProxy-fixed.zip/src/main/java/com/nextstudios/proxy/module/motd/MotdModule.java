package com.nextstudios.proxy.module.motd;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyPingEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.ServerPing;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.maintenance.MaintenanceModule;
import com.nextstudios.proxy.util.Text;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class MotdModule extends Module {
    private static final List<String> SUBCOMMANDS = List.of("set", "version", "preview", "reset");
    private String line1;
    private String line2;
    private String version;
    private int protocol;
    private boolean hidePlayers;
    private int maxPlayers;
    private String permission;

    public MotdModule(NextProxy plugin) {
        super(plugin, "motd");
    }

    @Override
    protected void onEnable() {
        this.permission = this.config().getString("commands.motd.permission", "nextproxy.motd");
        this.readConfig();
        this.plugin.dataRepository().get("motd.line1").thenAccept(value -> {
            if (value.isPresent() && !value.get().isEmpty()) {
                this.line1 = value.get();
            }
        }).exceptionally(error -> null);
        this.plugin.dataRepository().get("motd.line2").thenAccept(value -> {
            if (value.isPresent() && !value.get().isEmpty()) {
                this.line2 = value.get();
            }
        }).exceptionally(error -> null);
        this.plugin.dataRepository().get("motd.version").thenAccept(value -> {
            if (value.isPresent()) {
                this.version = value.get();
            }
        }).exceptionally(error -> null);
        this.listen(this);
        this.command("motd", spec -> new MotdCommand(spec));
    }

    private void readConfig() {
        this.line1 = this.config().getString("line1", "");
        this.line2 = this.config().getString("line2", "");
        this.version = this.config().getString("version", "");
        this.protocol = this.config().getInt("version-protocol", -1);
        this.hidePlayers = this.config().getBoolean("hide-players", false);
        this.maxPlayers = this.config().getInt("max-players", -1);
    }

    @Subscribe
    public void onPing(ProxyPingEvent event) {
        YamlConfig maintenance = this.maintenancePing();
        boolean maintenanceActive = maintenance != null;
        String first = maintenanceActive ? maintenance.getString("line1", "") : this.line1;
        String second = maintenanceActive ? maintenance.getString("line2", "") : this.line2;
        String versionText = maintenanceActive ? maintenance.getString("version", "<red>Manutenzione") : this.version;

        TagResolver[] resolvers = new TagResolver[] {
            Text.token("online", this.proxy().getPlayerCount()),
            Text.token("max", this.maxPlayers >= 0 ? this.maxPlayers : this.proxy().getConfiguration().getShowMaxPlayers()),
            Text.token("version", this.proxy().getVersion().getVersion())
        };

        ServerPing.Builder builder = event.getPing().asBuilder()
                .description(this.messages().parse(first + "\n" + second, resolvers));
        if (!versionText.isEmpty()) {
            builder.version(new ServerPing.Version(this.protocol, Text.legacySection(this.messages().parse(versionText, resolvers))));
        }
        if (this.hidePlayers || maintenanceActive && maintenance.getBoolean("hide-players", false)) {
            builder.nullPlayers();
        }
        if (this.maxPlayers >= 0) {
            builder.onlinePlayers(this.proxy().getPlayerCount()).maximumPlayers(this.maxPlayers);
        }
        event.setPing(builder.build());
    }

    private YamlConfig maintenancePing() {
        MaintenanceModule maintenance = this.plugin.module(MaintenanceModule.class);
        if (maintenance == null || !maintenance.isEnabled() || !maintenance.isActive()) {
            return null;
        }
        YamlConfig section = this.plugin.moduleConfig("maintenance").section("ping");
        return section.getBoolean("enabled", true) && section.contains("line1") ? section : null;
    }

    private void save(String key, String value) {
        this.plugin.dataRepository().set(key, value).exceptionally(error -> {
            this.logger().error("Impossibile salvare il MOTD", error);
            return null;
        });
    }

    private final class MotdCommand extends BaseCommand {
        MotdCommand(CommandSpec spec) {
            super(MotdModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            String sub = args.length == 0 ? "preview" : args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "set" -> this.set(source, args);
                case "version" -> this.version(source, args);
                case "reset" -> this.reset(source);
                default -> this.preview(source);
            }
        }

        private void set(CommandSource source, String[] args) {
            if (args.length < 3 || (!args[1].equals("1") && !args[1].equals("2"))) {
                this.messages().usage(source, "usage-set");
                return;
            }
            String text = join(args, 2);
            if (text.isEmpty()) {
                this.messages().usage(source, "usage-set");
                return;
            }
            if (args[1].equals("1")) {
                MotdModule.this.line1 = text;
                MotdModule.this.save("motd.line1", text);
            } else {
                MotdModule.this.line2 = text;
                MotdModule.this.save("motd.line2", text);
            }
            this.messages().send(source, "line-updated", Text.token("line", args[1]));
            this.preview(source);
        }

        private void version(CommandSource source, String[] args) {
            if (args.length < 2) {
                this.messages().usage(source, "usage-version");
                return;
            }
            MotdModule.this.version = join(args, 1);
            MotdModule.this.save("motd.version", MotdModule.this.version);
            this.messages().send(source, "version-updated", Text.literal("version", MotdModule.this.version));
        }

        private void reset(CommandSource source) {
            MotdModule.this.readConfig();
            MotdModule.this.save("motd.line1", "");
            MotdModule.this.save("motd.line2", "");
            MotdModule.this.save("motd.version", "");
            this.messages().send(source, "reset", new TagResolver[0]);
            this.preview(source);
        }

        private void preview(CommandSource source) {
            TagResolver[] resolvers = new TagResolver[] {
                Text.token("online", MotdModule.this.proxy().getPlayerCount()),
                Text.token("max", MotdModule.this.maxPlayers >= 0 ? MotdModule.this.maxPlayers : MotdModule.this.proxy().getConfiguration().getShowMaxPlayers()),
                Text.token("version", MotdModule.this.proxy().getVersion().getVersion())
            };
            Component line1 = MotdModule.this.messages().parse(MotdModule.this.line1, resolvers);
            Component line2 = MotdModule.this.messages().parse(MotdModule.this.line2, resolvers);
            this.messages().send(source, "preview-header", new TagResolver[0]);
            source.sendMessage(line1);
            source.sendMessage(line2);
            for (Player player : MotdModule.this.proxy().getAllPlayers()) {
                if (!player.hasPermission(MotdModule.this.permission)) {
                    continue;
                }
                this.messages().send(player, "preview-updated", Text.token("player", MotdModule.this.plugin.nameOf(source)));
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length <= 1) {
                return filter(SUBCOMMANDS, args.length == 0 ? "" : args[0]);
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
                return filter(List.of("1", "2"), args[1]);
            }
            return List.of();
        }
    }
}
