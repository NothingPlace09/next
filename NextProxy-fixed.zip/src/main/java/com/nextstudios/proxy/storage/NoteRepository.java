package com.nextstudios.proxy.storage;

import com.nextstudios.proxy.storage.Database;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class NoteRepository {
    private final Database db;

    public NoteRepository(Database db) {
        this.db = db;
    }

    public CompletableFuture<Long> add(UUID target, UUID author, String authorName, String text, long now) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("notes") + " (target_uuid, author_uuid, author_name, note, created_at) VALUES (?, ?, ?, ?, ?)", 1);){
                statement.setString(1, target.toString());
                statement.setString(2, author == null ? null : author.toString());
                statement.setString(3, authorName);
                statement.setString(4, text);
                statement.setLong(5, now);
                statement.executeUpdate();
                try (ResultSet keys = statement.getGeneratedKeys();){
                    if (keys.next()) {
                        Long l = keys.getLong(1);
                        return l;
                    }
                }
                throw new SQLException("Nessun id generato per la nota");
            }
        });
    }

    public CompletableFuture<Boolean> remove(UUID target, long id) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM " + this.db.table("notes") + " WHERE id = ? AND target_uuid = ?");){
                statement.setLong(1, id);
                statement.setString(2, target.toString());
                Boolean bl = statement.executeUpdate() > 0;
                return bl;
            }
        });
    }

    public CompletableFuture<List<Note>> list(UUID target) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT id, author_name, note, created_at FROM " + this.db.table("notes") + " WHERE target_uuid = ? ORDER BY id ASC");){
                statement.setString(1, target.toString());
                ArrayList<Note> result = new ArrayList<Note>();
                try (ResultSet rs = statement.executeQuery();){
                    while (rs.next()) {
                        result.add(new Note(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getLong(4)));
                    }
                }
                ArrayList<Note> arrayList = result;
                return arrayList;
            }
        });
    }

    public CompletableFuture<Integer> count(UUID target) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM " + this.db.table("notes") + " WHERE target_uuid = ?");){
                Integer n;
                block12: {
                    statement.setString(1, target.toString());
                    ResultSet rs = statement.executeQuery();
                    try {
                        n = rs.next() ? rs.getInt(1) : 0;
                        if (rs == null) break block12;
                    }
                    catch (Throwable throwable) {
                        if (rs != null) {
                            try {
                                rs.close();
                            }
                            catch (Throwable throwable2) {
                                throwable.addSuppressed(throwable2);
                            }
                        }
                        throw throwable;
                    }
                    rs.close();
                }
                return n;
            }
        });
    }

    public record Note(long id, String authorName, String text, long createdAt) {
    }
}
