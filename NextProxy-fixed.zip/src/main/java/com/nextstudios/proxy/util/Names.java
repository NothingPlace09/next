package com.nextstudios.proxy.util;

import com.velocitypowered.api.proxy.Player;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public final class Names {
    private static final Pattern DEFAULT_NAME = Pattern.compile("^[a-zA-Z0-9_.]{1,16}$");
    private static final Pattern IPV4 = Pattern.compile("^((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$");
    private static final Pattern IPV6 = Pattern.compile("^[0-9a-fA-F:.]{2,45}$");
    private static volatile Pattern namePattern = DEFAULT_NAME;

    private Names() {
    }

    public static boolean setNamePattern(String regex) {
        try {
            namePattern = Pattern.compile(regex);
            return true;
        }
        catch (PatternSyntaxException e) {
            namePattern = DEFAULT_NAME;
            return false;
        }
    }

    public static boolean isValidName(String input) {
        return input != null && input.length() <= 32 && namePattern.matcher(input).matches();
    }

    public static boolean isIp(String input) {
        if (input == null) {
            return false;
        }
        return IPV4.matcher(input).matches() || input.indexOf(58) >= 0 && IPV6.matcher(input).matches();
    }

    public static String ipOf(Player player) {
        InetAddress address;
        InetSocketAddress remote = player.getRemoteAddress();
        InetAddress inetAddress = address = remote == null ? null : remote.getAddress();
        if (address == null) {
            return "unknown";
        }
        String ip = address.getHostAddress();
        int scope = ip.indexOf(37);
        return scope >= 0 ? ip.substring(0, scope) : ip;
    }
}
