package com.nextstudios.common;

import java.util.Map;

public final class LegacyText {
    private static final Map<Character, String> CODES = Map.ofEntries(Map.entry(Character.valueOf('0'), "<black>"), Map.entry(Character.valueOf('1'), "<dark_blue>"), Map.entry(Character.valueOf('2'), "<dark_green>"), Map.entry(Character.valueOf('3'), "<dark_aqua>"), Map.entry(Character.valueOf('4'), "<dark_red>"), Map.entry(Character.valueOf('5'), "<dark_purple>"), Map.entry(Character.valueOf('6'), "<gold>"), Map.entry(Character.valueOf('7'), "<gray>"), Map.entry(Character.valueOf('8'), "<dark_gray>"), Map.entry(Character.valueOf('9'), "<blue>"), Map.entry(Character.valueOf('a'), "<green>"), Map.entry(Character.valueOf('b'), "<aqua>"), Map.entry(Character.valueOf('c'), "<red>"), Map.entry(Character.valueOf('d'), "<light_purple>"), Map.entry(Character.valueOf('e'), "<yellow>"), Map.entry(Character.valueOf('f'), "<white>"), Map.entry(Character.valueOf('k'), "<obfuscated>"), Map.entry(Character.valueOf('l'), "<bold>"), Map.entry(Character.valueOf('m'), "<strikethrough>"), Map.entry(Character.valueOf('n'), "<underlined>"), Map.entry(Character.valueOf('o'), "<italic>"), Map.entry(Character.valueOf('r'), "<reset>"));

    private LegacyText() {
    }

    public static String toMiniMessage(String input) {
        if (input == null) {
            return "";
        }
        if (input.indexOf(38) < 0 && input.indexOf(167) < 0) {
            return input;
        }
        StringBuilder out = new StringBuilder(input.length() + 16);
        boolean inTag = false;
        for (int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            if (c == '<') {
                inTag = true;
            } else if (c == '>') {
                inTag = false;
            }
            if (!(inTag || c != '&' && c != '\u00a7' || i + 1 >= input.length())) {
                char next = input.charAt(i + 1);
                if (next == '#' && LegacyText.isHex(input, i + 2, 6)) {
                    out.append("<#").append(input, i + 2, i + 8).append('>');
                    i += 7;
                    continue;
                }
                if ((next == 'x' || next == 'X') && LegacyText.isBungeeHex(input, i + 2)) {
                    out.append("<#");
                    for (int k = 0; k < 6; ++k) {
                        out.append(input.charAt(i + 3 + k * 2));
                    }
                    out.append('>');
                    i += 13;
                    continue;
                }
                String tag = CODES.get(Character.valueOf(Character.toLowerCase(next)));
                if (tag != null) {
                    out.append(tag);
                    ++i;
                    continue;
                }
            }
            out.append(c);
        }
        return out.toString();
    }

    private static boolean isHex(String s, int from, int length) {
        if (from + length > s.length()) {
            return false;
        }
        for (int i = from; i < from + length; ++i) {
            if (Character.digit(s.charAt(i), 16) >= 0) continue;
            return false;
        }
        return true;
    }

    private static boolean isBungeeHex(String s, int from) {
        if (from + 12 > s.length()) {
            return false;
        }
        for (int k = 0; k < 6; ++k) {
            char marker = s.charAt(from + k * 2);
            if ((marker == '&' || marker == '\u00a7') && Character.digit(s.charAt(from + k * 2 + 1), 16) >= 0) continue;
            return false;
        }
        return true;
    }
}
