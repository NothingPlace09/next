package com.nextstudios.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class SignedMessage {
    public static final int MAC_LENGTH = 32;
    public static final int MAX_SIZE = Short.MAX_VALUE;
    private static final String ALGORITHM = "HmacSHA256";
    private final SecretKeySpec key;

    public SignedMessage(byte[] secret) {
        if (secret == null || secret.length < 16) {
            throw new IllegalArgumentException("Il segreto del bridge deve avere almeno 16 byte");
        }
        this.key = new SecretKeySpec((byte[])secret.clone(), ALGORITHM);
    }

    public byte[] seal(int type, Body body) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(128);
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeByte(1);
        out.writeByte(type);
        body.write(out);
        out.flush();
        byte[] payload = bytes.toByteArray();
        byte[] result = Arrays.copyOf(payload, payload.length + 32);
        System.arraycopy(this.mac(payload), 0, result, payload.length, 32);
        if (result.length > Short.MAX_VALUE) {
            throw new IOException("Messaggio troppo grande: " + result.length + " byte");
        }
        return result;
    }

    public Opened open(byte[] data) throws InvalidMessageException {
        byte[] actual;
        if (data == null || data.length < 34 || data.length > Short.MAX_VALUE) {
            throw new InvalidMessageException("lunghezza non valida");
        }
        int payloadLength = data.length - 32;
        byte[] expected = this.mac(Arrays.copyOf(data, payloadLength));
        if (!MessageDigest.isEqual(expected, actual = Arrays.copyOfRange(data, payloadLength, data.length))) {
            throw new InvalidMessageException("firma non valida (segreto diverso tra proxy e bridge?)");
        }
        if (data[0] != 1) {
            throw new InvalidMessageException("versione del protocollo non supportata: " + data[0]);
        }
        int type = data[1] & 0xFF;
        return new Opened(type, new DataInputStream(new ByteArrayInputStream(data, 2, payloadLength - 2)));
    }

    private byte[] mac(byte[] payload) {
        try {
            Mac mac = Mac.getInstance(ALGORITHM);
            mac.init(this.key);
            return mac.doFinal(payload);
        }
        catch (GeneralSecurityException e) {
            throw new IllegalStateException("HmacSHA256 non disponibile", e);
        }
    }

    @FunctionalInterface
    public static interface Body {
        public static final Body EMPTY = out -> {};

        public void write(DataOutputStream var1) throws IOException;
    }

    public static final class InvalidMessageException
    extends Exception {
        public InvalidMessageException(String message) {
            super(message);
        }
    }

    public record Opened(int type, DataInputStream in) {
    }
}
